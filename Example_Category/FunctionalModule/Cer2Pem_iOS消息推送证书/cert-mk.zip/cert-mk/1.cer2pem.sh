#!/bin/sh

openssl x509 -in $1 -inform der -out $2

