#!/bin/sh

openssl pkcs12 -nocerts -in $1 -out $2
