#!/bin/sh

cat $1 $2 > $3

