#!/bin/sh

openssl rsa -in $1 -out $2


